<?php

echo "Halo Smart Developer";

?>